<div class="col-md-12">
    <?php echo $this->session->flashdata('alert_message') ?>
</div>